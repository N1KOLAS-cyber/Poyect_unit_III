import os

CARPETA_DOCS = "documentos"
os.makedirs(CARPETA_DOCS, exist_ok=True)

palabras_base = [
    "hola", "mundo", "tecnología", "python", "sistema", "programa", "estudiante", "documento",
    "universidad", "proyecto", "algoritmo", "hash", "similitud", "ordenamiento", "estructura",
    "datos", "texto", "comparación", "ngrama", "tabla", "función", "visualización", "código",
    "modular", "archivo", "proceso", "memoria", "optimización", "búsqueda", "eficiencia"
]
